def function():
    print("Hello World")    

print("Hello World")