import requests

def exploit(id):
    name = "Showen"
